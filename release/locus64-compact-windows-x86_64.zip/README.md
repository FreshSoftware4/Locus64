# Locus64 compact Windows Release

Primary command: .\l64.exe

Verified commands:
- cargo test -q
- torture test with one outer round and one namespace

Linux binary packaging is not included from this Windows host because x86_64-unknown-linux-gnu requires a local GNU linker (cc), which is missing.

Q-surface crates remain extraction/deletion targets, not public language commitments.
