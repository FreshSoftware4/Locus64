# Locus64 Source Release

Build and test:

```powershell
cargo test -q
cargo build --release -p l64 -p l64-cli -p l64-admin
```

Primary command: l64.

Linux binary cross-build note: x86_64-unknown-linux-gnu target is installed locally, but linking requires a GNU cc linker that is not installed on this host.
