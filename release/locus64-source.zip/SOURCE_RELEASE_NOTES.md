# Locus64 Source Release

This package contains the Rust workspace, samples, scripts, and documentation needed to build and develop Locus64.

Build fast binaries:
  cargo build --profile perfopt -p mf -p mf-cli -p mf-admin

Build compact binaries:
  cargo build --profile compact -p mf -p mf-cli -p mf-admin

Run verification:
  cargo fmt --check
  cargo test -q
  powershell -ExecutionPolicy Bypass -File .\scripts\torture-test.ps1 -OuterRounds 1 -InnerNamespaces 1

For Linux x86_64 from Windows, this pass used cargo-zigbuild because plain cargo lacked a local cc linker:
  cargo zigbuild --profile perfopt --target x86_64-unknown-linux-gnu -p mf -p mf-cli -p mf-admin
  cargo zigbuild --profile compact --target x86_64-unknown-linux-gnu -p mf -p mf-cli -p mf-admin
