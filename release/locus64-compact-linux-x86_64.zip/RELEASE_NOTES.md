# Locus64 Compact Binary Release

Profile: compact
Purpose: minimized storage/footprint release.
Build flags: opt-level=z, LTO, one codegen unit, abort panic, stripped.

Run Windows:
  .\mf.exe surface-capabilities

Run Linux:
  chmod +x ./mf ./mf-cli ./mf-admin
  ./mf surface-capabilities

Keep mf, mf-cli, and mf-admin in the same directory. The mf wrapper dispatches to sibling binaries.
